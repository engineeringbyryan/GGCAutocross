GGC Autocross system as seen @ http://www.ggcbmwcca.org/autocross

Currently this authenticates against Joomla.


